<?php
session_start();
include "connect.php";

$error = "";

if (isset($_POST['email'])) {
    $email    = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $sql    = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        if (password_verify($password, $row['password'])) {
            $_SESSION['user']    = $row['name'];
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['role']    = $row['role'];
            header("Location: pages/dashboard.php");
            exit();
        } else {
            $error = "Invalid email or password.";
        }
    } else {
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SkillSync</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .login-wrapper {
            min-height: calc(100vh - 70px);
            display: flex; align-items: center; justify-content: center;
            padding: 40px 20px;
            background: linear-gradient(135deg, #e6ecf7 0%, #f4f6fb 100%);
        }
        .login-card {
            background: white; border-radius: 16px;
            box-shadow: 0 8px 32px rgba(44,74,154,0.12);
            padding: 40px; width: 100%; max-width: 400px;
        }
        .card-header { text-align: center; margin-bottom: 28px; }
        .card-header h1 { font-size: 24px; color: #1e3a8a; margin: 0 0 6px; }
        .card-header p  { color: #6b7280; font-size: 14px; margin: 0; }
        .form-group { display: flex; flex-direction: column; gap: 5px; margin-bottom: 16px; }
        .form-group label { font-size: 13px; font-weight: 600; color: #374151; }
        .form-group input {
            padding: 10px 12px; border: 1.5px solid #e5e7eb;
            border-radius: 8px; font-size: 14px; background: #f9fafb;
            outline: none; transition: border-color 0.2s;
        }
        .form-group input:focus {
            border-color: #2c4a9a;
            box-shadow: 0 0 0 3px rgba(44,74,154,0.1);
            background: white;
        }
        .error-msg {
            background: #fee2e2; color: #991b1b;
            padding: 10px 14px; border-radius: 8px;
            font-size: 14px; margin-bottom: 16px;
        }
        .submit-btn { width: 100%; padding: 12px; font-size: 15px; font-weight: 600; border-radius: 8px; margin-top: 4px; }
        .bottom-links { text-align: center; margin-top: 20px; font-size: 13px; color: #6b7280; }
        .bottom-links a { color: #2c4a9a; font-weight: 600; text-decoration: none; }
        .bottom-links a:hover { text-decoration: underline; }
        .divider { border: none; border-top: 1px solid #f3f4f6; margin: 16px 0; }
    </style>
</head>
<body>
<?php include 'includes/navbar.php'; ?>

<div class="login-wrapper">
    <div class="login-card">
        <div class="card-header">
            <h1>Welcome back</h1>
            <p>Login to your SkillSync account</p>
        </div>

        <?php if ($error): ?>
            <div class="error-msg"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="you@example.com" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Your password" required>
            </div>
            <button type="submit" class="submit-btn">Login</button>
        </form>

        <hr class="divider">

        <div class="bottom-links">
            New student? <a href="pages/student_signup.php">Create an account</a>
            <br><br>
            Want to teach? <a href="pages/signup.php">Become a Tutor</a>
        </div>
    </div>
</div>
</body>
</html>
